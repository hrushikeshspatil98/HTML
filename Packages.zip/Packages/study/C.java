package study;

public class C
{
 public void aboutC()
 {
  System.out.println("C helps learning various programming concepts");
 }//aboutC
}//C