package study;

public class Cpp
{
 public void aboutCpp()
 {
  System.out.println("C++ helps learning OOP concepts");
 }//aboutCpp
}//Cpp