package study;

class JavaScript
{
 void aboutJS()
 {
  System.out.println("JS allows client side processing for a web application");
 }//aboutJS
}//JavaScript