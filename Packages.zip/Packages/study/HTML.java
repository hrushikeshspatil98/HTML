package study;

public class HTML
{
 public void aboutHTML()
 {
  System.out.println("HTML helps develop web applications ");
  JavaScript jsObj = new JavaScript();
  jsObj.aboutJS();
 }//aboutHTML
}//HTML