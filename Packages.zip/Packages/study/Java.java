package study;

public class Java
{
 public void aboutJava()
 {
  System.out.println("Java helps implement programming concepts");
 }//aboutJava
}//Java