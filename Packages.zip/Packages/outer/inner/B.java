package outer.inner;

public class B
{
 public void fx3()
 {
  System.out.println("Outer Inner B fx3");
 }
}