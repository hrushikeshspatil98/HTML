package outer.inner;

public class C
{
 public void fx4()
 {
  System.out.println("Outer Inner C fx4");
 }
}