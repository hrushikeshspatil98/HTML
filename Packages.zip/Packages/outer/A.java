package outer;

public class A
{
 public void fx1()
 {
  System.out.println("Outer A fx1");
 }
}