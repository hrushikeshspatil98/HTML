package outer;

public class B
{
 public void fx2()
 {
  System.out.println("Outer B fx2");
 }
}