
public class DataTypes {

	public static void main(String[] args) {
		byte a = 20;
		short b = 1387;
		long l = 2345678;
		int c = 1;
		float f = 2.34f;
		double d = 12345.6543;
		char m = 'S';
		System.out.println(a);
		System.out.println(b);
		System.out.println(l);
		System.out.println(c);
		System.out.println(f);
		System.out.println(d);
		System.out.println(m);

	}

}
