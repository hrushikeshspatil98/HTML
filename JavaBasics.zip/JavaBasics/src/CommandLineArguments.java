
public class CommandLineArguments {

	public static void main(String[] args) {
		int length = args.length;
		System.out.println("Length Is "+length);
		if(length == 0) {
			System.out.println("No Inputs Are Provided");
		}else {
			System.out.println("Provided Inputs Are");
			for(int i = 0;i < length;i++) {
				System.out.println(args[i]);
			}
		}
	}

}
