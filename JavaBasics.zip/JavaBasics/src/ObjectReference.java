
public class ObjectReference {
	int x;

	ObjectReference() {

	}

	public static void main(String[] args) {
		ObjectReference ord = new ObjectReference();
		System.out.println(ord.x);

	}

}
