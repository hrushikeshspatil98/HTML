
public class Sample {
	public static void main(String[] args) {
		int n = 10;
		System.out.println(n);
		

	}

}
