
public class PrimitiveAndObjects {

	public static void main(String[] args) {
		int x = 25;
		//Boxing Primitive To Object
		Integer y = Integer.valueOf(x); // Static Method Because We Used Class Name
		//Unboxing Object To Primitive
		int z = y.intValue(); // Non Static Method Because We Used Object Reference
		System.out.println(y);
		System.out.println(z);
	}

}
