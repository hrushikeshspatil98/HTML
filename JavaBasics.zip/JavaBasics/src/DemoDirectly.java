
public class DemoDirectly {
	static DemoDirectly d;
	static {
		System.out.println(DemoDirectly.d);
		DemoDirectly.d = new DemoDirectly();
	}

	public static void main(String[] args) {
		System.out.println(DemoDirectly.d);
	}
}
