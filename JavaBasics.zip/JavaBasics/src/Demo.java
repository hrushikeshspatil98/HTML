
public class Demo {
	static{
		Demo d = new Demo();
		System.out.println(d);
	}
	public static void main(String[] args) {
		
	}

}
