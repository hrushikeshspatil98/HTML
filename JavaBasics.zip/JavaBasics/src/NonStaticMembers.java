
public class NonStaticMembers {
	int n;

	NonStaticMembers() {
		System.out.println("Inside The Constructor");
	}

	{
		System.out.println("Inside The Non Static Block");
	}

	public static void main(String[] args) {
		System.out.println("Inside The Main Method");
		//new NonStaticMembers();
		// Difference Between Static And Non Static 
		//new NonStaticMembers();
		//new NonStaticMembers();
		 NonStaticMembers n = new  NonStaticMembers();
		 n.init();

	}

	static {
		System.out.println("Inside The Static Block");
	}
	void init() {
		System.out.println("Inside The Init Method");
	}

}
