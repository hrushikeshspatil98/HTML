
public class ImplicitTypeCasting {

	public static void main(String[] args) {
		byte b = 10;
		int a = b;
		char ch = 'a';
		int c = ch;
		System.out.println(a);
		System.out.println(c);
	}

}
