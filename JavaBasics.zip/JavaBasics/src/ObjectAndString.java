
public class ObjectAndString {

	public static void main(String[] args) {
		long x = 1000;
		Long z =Long.valueOf(x);
		String s = z.toString();
		Long a =Long.valueOf(s);
		System.out.println(a);
	}

}
