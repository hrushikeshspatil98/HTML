
public class StaticMethod {

	public static void main(String[] args) {
		System.out.println("Main Method");
		StaticMethod.printMethod();
	}

	static void printMethod() {
		System.out.println("Inside Static Method");
	}
	static {
		System.out.println("Inside Static Block");
		StaticMethod.printMethod();
	}
}

