
public class PrimitiveAndString {

	public static void main(String[] args) {
		byte b = 100;
		String s = Byte.toString(b); // Static Method Because We Used Class Name
		byte z = Byte.parseByte(s); // Static Method Because We Used Class Name
		System.out.println(s);
		System.out.println(z);
	}

}
