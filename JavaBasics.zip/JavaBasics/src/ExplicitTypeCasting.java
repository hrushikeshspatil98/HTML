
public class ExplicitTypeCasting {

	public static void main(String[] args) {
		int a = 97;
		char ch = (char)a;
		System.out.println(ch);
		int d = 100;
		byte b = (byte)d;
		System.out.println(b);
	}

}
