
public class Static {
	static Static s = new Static();
	static{
		System.out.println(Static.s);
		Static.s = Static.init();
	}
	public static void main(String[] args) {
		System.out.println(Static.s);
	}
	static Static init() {
		return new Static();
	}
}
