
public class StaticMethodDemo {
	static StaticMethodDemo d = new StaticMethodDemo();
	static {
		System.out.println(StaticMethodDemo.d);
		StaticMethodDemo.init();
	}
	public static void main(String[] args) {
		System.out.println(StaticMethodDemo.d);
	}
	static void init() {
		StaticMethodDemo.d = new StaticMethodDemo();
	}
}
