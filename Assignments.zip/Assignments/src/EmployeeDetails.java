
public class EmployeeDetails {

	public static void main(String[] args) {
		int id = 12345;
		String name = "Shubham Jadhav";
		String dept = "Software Devlopment";
		boolean Active = false;
		System.out.println(id);
		System.out.println(name);
		System.out.println(dept);
		if(Active == true) {
			System.out.println("Active");
		}
		else {
			System.out.println("Non Active");
		}

	}

}
