
public class VariableAssignments {

	public static void main(String[] args) {
		int a = 10;
		float f = 20.54f;
		char ch = 'X';
		String str = "I Am The Best";
		System.out.println(a);
		System.out.println(f);
		System.out.println(ch);
		System.out.println(str);
	}

}
