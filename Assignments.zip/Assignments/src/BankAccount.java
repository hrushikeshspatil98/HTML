
public class BankAccount {
	static String bankName = "State Bank Of India";
	String name;
	String accNo;
	String accType;
	boolean Active;
	double balance;
	public static void main(String[] args) {
		BankAccount b = new BankAccount();
		b.name = "Sukanya Gade";
		b.accNo = "8876543890B";
		b.accType = "Saving Account";
		b.Active = true;
		b.balance = 25000;
		System.out.println("Name Of Bank : "+bankName);
		System.out.println("Account Holder Name : "+b.name);
		System.out.println("Account Number : "+b.accNo);
		System.out.println("Type Of Account : "+b.accType);
		System.out.println("Accout Is : "+b.Active);
		System.out.println("Balance : "+b.balance);
		
	}

}
