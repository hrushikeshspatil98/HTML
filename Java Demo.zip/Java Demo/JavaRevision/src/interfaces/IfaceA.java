package interfaces;

public interface IfaceA {
	final static double pi = 3.14;
	
	double findArea(double a, double b);
	double findAreaOfOthers(int d);
	
	default void display()
	{
		System.out.println("Default Method : IfaceA");
	}
	
	static void valueOfPi()
	{
		System.out.println("Value of pi is : "+pi);
	}
	
}
