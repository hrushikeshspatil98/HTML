package interfaces;

interface ClassIface {

	class A
	{
		int x,y;
		static int sum =0 ;
		
		A(int x,int y)
		{
			this.x = x;
			this.y = y;
		}
		
		void dispSum()
		{
			sum += x + y;
			System.out.println("Sum is: "+sum);
		}
	}
}

public class ClassInInterface implements ClassIface{

	public static void main(String[] args) {
		
		
		A classIface = new ClassIface.A(10,20);
//		A classIface = new A(10,20);
		System.out.println("Default sum: "+A.sum);
		classIface.dispSum();
		
		A classIface1 = new ClassIface.A(20,20);
		System.out.println("Default sum: "+A.sum);
		classIface1.dispSum();
		
	}

}

/*
		Output:
			Default sum: 0
			Sum is: 30
			Default sum: 30
			Sum is: 70
*/