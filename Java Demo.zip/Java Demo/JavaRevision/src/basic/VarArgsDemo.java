package basic;
//Demo for Variable Arguments Method - introduce in java 5
public class VarArgsDemo {

	//A variable-length argument is specified by three periods or dots(…) in varargs method
	int sumOfNums(int ...values)
	{
		int sum = 0;
		for(int i=0; i<values.length; i++)
		{
			sum += values[i];
		}
		return sum;
	}
	
	public static void main(String[] args) {
		VarArgsDemo vargs = new VarArgsDemo();
		System.out.println(vargs.sumOfNums(10,20)); 
		System.out.println(vargs.sumOfNums(10,20,30));
		System.out.println(vargs.sumOfNums(10,20,30,40,50));
		// We can pass variable number of parameters (but of same data type) to method 
		// Internally it combines all parameter as elements in an array. And reference of that array is 
		// passed as argument to varargs method
	}

}

/*
Output:
	40
	110
	570
*/