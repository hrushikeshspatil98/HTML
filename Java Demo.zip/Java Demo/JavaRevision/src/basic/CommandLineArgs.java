package basic;

public class CommandLineArgs {

	public static void main(String[] args) {
		
		System.out.println("No of arguments passed through cmd line is : "+args.length);
		
		System.out.println("Arguments: ");
		for(String s : args)
			System.out.println(s);
		
		System.out.println("Concated String is: "+args[0].concat(" ").concat(args[1]).concat(args[2]));
		
		System.out.println("Multiplied Result : "+Integer.parseInt(args[3]) * Integer.parseInt(
				args[4]));
	}

}

// > java CommandLineArgs Welcome User ! 10 20
/*
Output:
	No of arguments passed through cmd line is : 5
	Arguments: 
	Welcome
	User
	!
	10
	20
	Concated String is: Welcome User!
	Multiplied Result : 200
*/