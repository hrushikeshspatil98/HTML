package basic;

public class AutoBoxingAndConversion {

	public static void main(String args[]) {
		/* int to Integer - boxing */
		
		int a = 10;
		//Integer aInt = new Integer(a); // deprecated - don't use
		Integer aInt = Integer.valueOf(a);
		Integer box = a;  // boxing
				
		System.out.println(box);
		System.out.println(aInt);

		System.out.println("**********");
		/* Integer to int - unboxing */
		
		//Integer b = new Integer(20);  // deprecated - don't use
		Integer b = Integer.valueOf(20);
		int unbox = b;   //unboxing
		int c = b.intValue();
		int d = Integer.parseInt(b.toString());
	
		System.out.println(unbox);
		System.out.println(c + " - "+ d);

	}
}
