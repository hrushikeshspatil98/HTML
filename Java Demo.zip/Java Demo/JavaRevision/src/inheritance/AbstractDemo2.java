package inheritance;

interface A
{
	void display();
	void desc();
}

abstract class AbstractExp1 implements A
{
	int num;
	static int res;

	AbstractExp1(){
		System.out.println("Constructor of : AbstractExp1");
	}
	
	public void display()		//If method is not defined here then sub class needs to implement/override this method
	{
		System.out.println("display()");
	}
	
}
class Abstr extends AbstractExp1
{

	@Override
	public void desc() {
		System.out.println("Abstr: desc()");
	}

	public void displayDet()
	{
		System.out.println("Object created and method called");
	}
	
//	@Override					//we can override display method here also
//	public void display() {}
}
public class AbstractDemo2 {

	public static void main(String[] args) {
		A a = new Abstr();
		a.display();
		a.desc();
		Abstr abstr = new Abstr();
		abstr.displayDet();
		
	}		

}

/* 
Output:
Constructor of : AbstractExp1
display()
Abstr: desc()
Constructor of : AbstractExp1
Object created and method called
*/
