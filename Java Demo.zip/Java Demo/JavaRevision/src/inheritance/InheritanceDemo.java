package inheritance;

class Car
{
	String name ;
	int war = 1;
	
	Car()
	{
		name = "Car";
	}
	void run()
	{
	System.out.println("Run() - Car");	
	}
	
	void run(String carName)  //Compile time polymorphism - Method Overloading
	{
		System.out.println("Run() - "+carName);	
	}
	
	void display()
	{
		System.out.println("Car Details");
	}
}
class Innova extends Car
{
	String carName;
	int war = 5;
	
	Innova() {
		//super();
		carName = "Innova";
		//super.run();
	}
	void run()		//Runtime polymorphism - Method Overriding
	{
		System.out.println("Run() - Innova");
	}
	
	void maxSpeed()
	{
		System.out.println("Max Speed is : 150");
	}
}
public class InheritanceDemo {

	public static void main(String[] args) {
		
		Innova innova = new Innova(); //Allowed - Sub Class reference refers to sub class object. It can access both inherited and extended code & data.
		System.out.println(innova.name + " : "+innova.carName);
		innova.run();
		innova.maxSpeed();
		System.out.println("**************");
		
		Car innovaCar = new Innova(); //Up casting Allowed - Super Class reference refers to sub class object but can access only inherited code & data
		innovaCar.run(); 
		innovaCar.display();
		System.out.println("**************");
		
		Car car = new Car(); //Allowed - Super Class reference refers to super class object. It can access only it's own code & data.
		car.run();
		car.display();
		
		System.out.println("**************");
		//Innova i1 = new Car(); //Down casting Implicitly Not allowed - Sub Class reference refers to super class object
		Car c1 = new Innova();
		Innova i1 = (Innova) c1; //Down casting explicitly
		i1.maxSpeed();
		i1.run();
		i1.display();
		System.out.println("Warrenty: Innova- "+i1.war+ " Car- "+c1.war);
		
		
	}

}

/* 
Output:
Car : Innova
Run() - Innova
Max Speed is : 150
**************
Run() - Innova
Car Details
**************
Run() - Car
Car Details
**************
Max Speed is : 150
Run() - Innova
Car Details
*/