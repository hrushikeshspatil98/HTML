/* 
 * Abstract class : ( we can achieve 0 to 100% abstraction)
 * ------------------
 *
 *
 * Abstract Method:
 * ------------------
 */

package inheritance;

abstract class AbstractExp
{
	int num;
	static int res;

	AbstractExp(){
		System.out.println("Constructor of : AbstractExp");
	}
	
	abstract void test();
	abstract void display();
	
	{ num = 20; System.out.println("NSIB");}
	static { res = 1; System.out.println("SIB");}
	
	public void logic(int number)
	{
		System.out.println("In logic()");
		for(int i=0; i<number; i++)
			res = res * num;
	}
	
	public static int testLogic()
	{
		return res;
	}
	
	final void testFinalMethod()
	{
		System.out.println("In Final Method");
	}
	
}
public class AbstractDemo extends AbstractExp{

	public static void main(String[] args) {
		AbstractExp abst = new AbstractDemo();
		abst.test();
		abst.display();
		abst.logic(3);
		
		System.out.println("Result: "+ AbstractExp.testLogic());
		System.out.println(AbstractExp.res);
		
		AbstractExp abst1 = new AbstractDemo();
		abst1.logic(1);
		System.out.println(AbstractExp.testLogic());
		abst1.testFinalMethod();
	}

	@Override
	void test() {
		System.out.println("Test Method in Sub Class: AbstractDemo");
	}

	@Override
	void display() {
		System.out.println("In Display()");
	}

}

/* 
Output: 

SIB
NSIB
Constructor of : AbstractExp
Test Method in Sub Class: AbstractDemo
In Display()
In logic()
Result: 8000
8000
NSIB
Constructor of : AbstractExp
In logic()
160000
In Final Method

*/