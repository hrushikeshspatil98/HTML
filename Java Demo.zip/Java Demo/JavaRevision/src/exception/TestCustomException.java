package exception;

class InvalidAgeException extends Exception  
{  
    
	private static final long serialVersionUID = -8513277512420306465L;

	public InvalidAgeException (String str)  
    {  
        // calling the constructor of parent Exception and passing exception message
        super(str);  
    }  
}  
    
public class TestCustomException
{  
  
    static void validate (int age) throws InvalidAgeException{    
       if(age < 18 && age > 60){  
    	   throw new InvalidAgeException("age is not valid to participate");    
       }  
       else {   
    	   System.out.println("welcome to competition");   
       }   
     }    
  
    public static void main(String args[])  
    {  
        try  
        {  
        	validate(13);  
        }  
        catch (InvalidAgeException ex)  
        {  
            System.out.println("Caught the exception");  
            System.out.println("Exception occured: " + ex);  
        }  
        finally
        {
        	System.out.println("Finally will always get executed in all the case (exception occurs or not, catched or not)");
        }
        
        System.out.println("rest of the code...");    
    }  
}  