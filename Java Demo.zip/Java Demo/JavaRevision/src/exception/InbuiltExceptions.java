package exception;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class InbuiltExceptions {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter Numbers for division: ");
		int n1 = in.nextInt();
		int n2 = in.nextInt();
		try {
		System.out.println(n1+"/"+n2+ " is "+n1/n2);
		}
		catch(ArithmeticException ae)
		{
			System.out.println("Divison Value is Zero");
		}
		
		int arr[]= {1,2,3};
		String s = "ABC";
		try {
			System.out.println("4rth Value in array is: "+arr[4]);
			System.out.println("4rth char in string is: "+ s.charAt(3));
		}
//		catch(ArrayIndexOutOfBoundsException ae)
//		{
//			System.out.println("Array size is 3");
//		}
//		catch(StringIndexOutOfBoundsException se)
//		{
//			System.out.println("Length of string is 3");
//		}
		catch(IndexOutOfBoundsException ie)
		{
			System.out.println("size/length of array and string is 3");
		}
		catch(Exception e)			//generic exception handler, should be specified in the last
		{
			System.out.println(e.getMessage());
		}
		
		in.close();
		
		FileReader fis = null;
		try {
			 fis = new FileReader("H:\\inp.txt");
			System.out.println("First letter in file is : "+(char)fis.read());
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		finally
		{
			int c;
			try {
				fis = new FileReader("H:\\input.txt");
				while((c = fis.read())!= -1)
				{
					System.out.print((char)c);
				}
				fis.close();
			} 
			catch (IOException e) {
				System.out.println(e.getMessage());
			} /*    //Unreachable catch block for FileNotFoundException. 
					//It is already handled by the catch block for IOException
				 * catch (FileNotFoundException e) { System.out.println(e.getMessage()); }
				 */
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}

}
