var hello = function(){
	
	print("Welcome to Nashorn");
	print("This is Javascript Engine");
	
};

hello();