//JSR 166 Fork/Join parallelism common pool - used to provide sorting of arrays in parallel

package parallelSort;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ParallelSort {

	public static void main(String[] args) {
		
		double numArr[]= {2.5, 1.5, 8.5, 9.5, 6.5};
		
		Arrays.parallelSort(numArr); // applicable for byte,char,int,long,float,double -> parallelSort(array,from,to) / parallelSort(array)
		Arrays.stream(numArr).forEach(n -> System.out.print(n+ " "));
		System.out.println();
		
		long longArr[] = {1234567893,234123,1234567891,123456987,912345789};
		Arrays.parallelSort(longArr, 2, longArr.length);
		Arrays.stream(longArr).forEach(n -> System.out.print(n+ " "));
		System.out.println();
		
		Integer arr[] = {5,3,12,8,6,14,19};
		Arrays.parallelSort(arr, Comparator.reverseOrder()); //applicable for object type elements -> parallelSort(T []array) / parallelSort(T []array, Comparator<? super T> cmp)
		//Arrays.parallelSort(arr, Collections.reverseOrder());
		Arrays.stream(arr).forEach(n -> System.out.print(n+ " "));
		System.out.println();
		
		Character charArr[] = {'A','W','C','B','H','R'};
		Arrays.parallelSort(charArr,1,charArr.length,Collections.reverseOrder()); // parallelSort(T []array, int fromIndex, int toIndex) / parallelSort(T []array, int fromIndex, int toIndex, Comparator<? super T> cmp)
		Arrays.stream(charArr).forEach(n -> System.out.print(n+ " "));
		
	}

}

/*
Output:
1.5 2.5 6.5 8.5 9.5 
1234567893 234123 123456987 912345789 1234567891 
19 14 12 8 6 5 3 
A W R H C B 
*/
