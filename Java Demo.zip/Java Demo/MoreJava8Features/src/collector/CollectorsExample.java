/*
	Collectors:
	============
	Collectors is a final class in java.util.stream package which provides reduction operations 
	such as accumulating elements into collections (list,map,..,etc) , summarizing elements 
	according to various criteria.
	
	More reference:  https://www.geeksforgeeks.org/java-collectors/
*/

package collector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.Stream.Builder;
import java.util.Map;

public class CollectorsExample {

	public static void main(String[] args) {
		
		List<String> strStartsWithO = Stream.of("Apple","Mango","Orange","Onion","Oil","Cake").
		filter(str -> str.startsWith("O")).collect(Collectors.toList());
		System.out.println("List is: "+strStartsWithO);
		
		Stream.of("Apple","Mango","Orange","Onion","Oil","Cake").
		filter(str -> str.startsWith("O")).collect(Collectors.toCollection(HashSet::new)).forEach(System.out::print);;
		
		System.out.println("\n Count is: "+Stream.of("Apple","Mango","Orange","Onion","Oil","Cake").collect(Collectors.counting()));
		
		System.out.println("Set is:");
		Stream.of("Apple","Mango","Orange","Onion","Oil","Cake","Oil","OrangE").filter(
		str -> str.startsWith("O")).collect(Collectors.toSet()).forEach(System.out::println);
		
		Map<Character, String> map= Stream.of("Apple","Mango","Orange","Cake").collect(Collectors.toMap(s -> s.charAt(0), s -> s ));
		System.out.println("Map is: "+map);
		
		List<Integer> intList = new ArrayList<Integer>(Arrays.asList(2,4,6,8,10,20,21,19));
		int sum = intList.stream().filter(num -> num % 2 == 0).collect(Collectors.summingInt(num -> num));
		double avg = intList.stream().filter(num -> num % 2 == 0).collect(Collectors.averagingInt(num -> num));
		System.out.println("Sum is: "+sum+ " Average is: "+avg);
		
		Builder<Double> builder = Stream.builder();
		builder.add(2.2).add(4.5).add(5.5);
		
		double dbSum = builder.build().collect(Collectors.summingDouble(num -> num));
		//double dbAvg = builder.build().collect(Collectors.averagingDouble(num -> num));
		System.out.println("Sum is: "+dbSum);
		
	}

}

/* Output:
List is: [Orange, Onion, Oil]
OilOnionOrange
 Count is: 6
Set is:
Oil
Onion
Orange
OrangE
Map is: {A=Apple, C=Cake, M=Mango, O=Orange}
Sum is: 50 Average is: 8.333333333333334
Sum is: 12.2
*/
