/*
 * Optional is a inbuilt public final class used to deal with null pointer exceptions in java.
 * It also provide methods to check presence of value for particular variable.
 */

package optional;

import java.util.Optional;

public class OptionalExample {

	public static void main(String []args)
	{
		String []str= new String[10];
		str[5] = "Welcome";
		//Optional<String> opt =Optional.of(str[5]); // of method is same as ofNullable, only difference is if specified value 
		//does not present then of will throw null pointer exception.
		Optional<String> opt =Optional.ofNullable(str[5]);
		Optional<String> empty = null;
		
		if(opt.isPresent())
		{
			System.out.println(opt); // Optional[Welcome]
			System.out.println(opt.get().toUpperCase()); // WELCOME
			
			empty = Optional.empty();
		}
		else
		{
			System.out.println("String value is not present in Optional Obj");
			empty = Optional.empty();
			System.out.println(empty); // if empty it will print Optional.empty
		}
		
		opt.ifPresent( s -> { System.out.println("Length of string is: "+s.length());}); // 7
		
		String res = opt.orElse("Value is not present");
		System.out.println(res);
		
		res = empty.orElse("Value is not present");
		System.out.println(res);
		
		res = empty.orElseGet(() -> new String("It's Empty"));
		System.out.println(res);
		
		System.out.println("Filtered Value: "+ opt.filter(s -> s.contains("el")));
		System.out.println("Filtered Value: "+ opt.filter(s -> s.contains("wel")));
		
	}
}

/* Output: 
Optional[Welcome]
WELCOME
Length of string is: 7
Welcome
Value is not present
It's Empty
Filtered Value: Optional[Welcome]
Filtered Value: Optional.empty
*/
