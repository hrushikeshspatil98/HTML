/*
Predicate: 
==========
 The predicate is a predefined functional interface in the java.util.Function package. 
 It is boolean valued function which accepts an argument and returns a boolean. 
 Usually, it used to apply filter for a collection of objects (stream)
 
Methods:
-------- 
test(T t) : It evaluates the predicate on the value passed as the argument and returns a
  			 boolean value.
isEqual(Object t) : It returns a predicate that tests if two objects are equal.
and(Predicate p) :  It returns a composed predicate that represents a logical AND of the 
 					 outputs coming from both predicates.
or(Predicate p) :  It returns a composed predicate that represents a logical OR of the 
 					 outputs coming from both predicates.
negate() : It returns a predicate that represents the logical negation of the respective predicate.
*/

package funIface;

import java.util.function.Predicate;
import java.util.stream.Stream;

public class PredicateIFace {

	public static void main(String[] args) {
		
		Predicate<Integer> pred1 = num -> num % 2 == 0;
		System.out.println(pred1.test(23));
		
		Predicate<Integer> pred2 =num -> num > 100;
		Predicate<Integer> pred3 =num -> num < 150;
		
		System.out.println(pred2.and(pred3).test(125));
		System.out.println(pred2.or(pred3).test(160));
		System.out.println(pred2.negate().test(121));
		
		Predicate<Integer> pred4 = (num) -> {for(int i=2; i<=num/2; i++)
			{
				if(num%i == 0)
				{ 
					return false;
				}
			}
		return true;	
		};
		
		Stream.of(4, 5, 7, 19, 21).forEach((num) -> System.out.println(num+ " Prime ? "+ pred4.test(num)));
		
		Predicate<String> pred5 = Predicate.isEqual("predicate");
		System.out.println("is Equal? "+pred5.test("predicate1"));
		
		Predicate<Integer> filterPred = num -> num % 2 != 0;
		System.out.println("Odd Numbers: ");
		Stream.of(4, 5, 7, 19, 21).filter(filterPred).forEach(System.out::println);
	}

}

/* Output: 
false
true
true
false
4 Prime ? false
5 Prime ? true
7 Prime ? true
19 Prime ? true
21 Prime ? false
is Equal? false
*/
