import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestStream2 {

	public static void main(String[] args) {
		
		System.out.println("Even Numbers upto 100: ");
		Stream.iterate(1, elem -> elem+1).
		filter(elem -> elem % 2 == 0).limit(50).
		forEach(System.out::println);
		
		List<Product> pList = new ArrayList<Product>();
		Collections.addAll(pList,new Product(1,"Ice-Cream Pack",160),new Product(2, "Cake",250),
				new Product(3,"Pen",20), new Product(4,"Pencil",10), new Product(5,"Pen Drive",200));
		
		Product maxProd= pList.stream().max((product1, product2) -> product1.price > product2.price ? 1: -1)
				.get();
		System.out.println("Max price product is :"+maxProd.getName()+ " -> "+maxProd.getPrice());
		
		Product minProd = pList.stream().min((p1, p2) -> p1.price> p2.price? 1: -1).get();
		//Product minProd = pList.stream().min((p1, p2) -> Integer.compare(p1.price, p2.price)).get();
		System.out.println("Min price product is :"+minProd.getName()+ " -> "+minProd.getPrice());
		
		System.out.println("Total products price is: ");
		//way 1
		int sum1= pList.stream().map(prod -> prod.price).reduce(0,(sum, price) -> sum += price);
		//float sum1= pList.stream().map(prod -> prod.price).reduce(0.0f,(sum, price) -> sum + price);
		System.out.println(sum1);
		
		//way 2
		int sum2= pList.stream().map(p -> p.price).reduce(0, Integer::sum);
		System.out.println(sum2);
		
		//way 3
		int sum3 = pList.stream().collect(Collectors.summingInt(p -> p.price));
		System.out.println(sum3);
		
		//sort nums
		Stream.of(49, 36, 16, 81, 100,64).sorted().forEach(System.out::println);
		Stream.of(49, 36, 16, 81, 100,64).sorted(Comparator.reverseOrder()).forEach(System.out::println);
	
		List<ProductData> pList1 = new ArrayList<ProductData>();
		Collections.addAll(pList1,new ProductData(2,"Ice-Cream Pack",160),new ProductData(4, "Cake",250),
				new ProductData(1,"Pen",20), new ProductData(3,"Pencil",10), new ProductData(5,"Pen Drive",200));
		
		pList1.stream().sorted(Comparator.comparingInt(ProductData :: getId).reversed()).forEach(System.out::println);
		//add - reversed() in case of descending order 
	}
}

class ProductData
{
	int id;
	String name;
	int price;
	ProductData(int id,String name,int price)
	{
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
}

