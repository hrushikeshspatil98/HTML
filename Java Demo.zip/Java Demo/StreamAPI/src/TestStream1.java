import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestStream1 {

	public static void main(String[] args) {
		Integer []arr = {10, 15, 25, 30, 49, 19};
		List<Integer> lst= Stream.of(arr).  //Stream source
				filter(x -> x%2 == 0).				   //Intermediate operation
				collect(Collectors.toList());		   //Terminal operation
		System.out.println("Even Num List: "+lst);
		lst.clear();
		
		//Integer []numArr= {10,25,10} ;
		Integer []numArr = null;
		//To avoid null pointer exception from Stream, we can use empty() method
		Stream<Integer> stream = numArr == null ? Stream.empty() : Stream.of(numArr);
		long count= stream.filter(x -> x%2 != 0).distinct().count();
		System.out.println("Count of distinct odd number objects in stream are: "+count);
	}

}
