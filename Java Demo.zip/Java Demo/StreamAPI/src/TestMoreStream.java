import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.Stream.Builder;

public class TestMoreStream {

	public static void main(String[] args) {
		// Stream building using Builder
		Builder<String> builder = Stream.builder();
		builder.add("Ice-Cream").add("Cake").add("Chocolate");
		
		Stream<String> stream = builder.build();
		stream.forEach(System.out::println);
		
		Builder<Product> prodBuilder= Stream.builder();
		prodBuilder.add(new Product(1,"Pen",20)).add(new Product(2,"Pencil",10)).add(new Product(3,"Eraser",10));
		Stream<Product> strProd = prodBuilder.build();
		strProd.forEach(System.out::println);
		
		//concatenation of two streams
		Builder<Product> prodBuild= Stream.builder();
		prodBuild.add(new Product(1,"Pen",20)).add(new Product(2,"Pencil",10)).add(new Product(3,"Eraser",10));
		Stream<Product> strProduct=  prodBuild.build();
				
		System.out.println("Stream after concat is: ");
		Stream.concat( Stream.builder().add("Ice-Cream").add("Cake").add("Chocolate").build(), strProduct.map(p -> p.name)).forEach(System.out::println);
		
		Builder<Product> prodBuilder1= Stream.builder();
		prodBuilder1.add(new Product(1,"Pen",20)).add(new Product(2,"Pencil",10)).add(new Product(3,"Eraser",10));
		Stream<Product> strProd1 = prodBuilder1.build();
		//Show products that is having price less than 20 in key value pair (map) format
		strProd1.filter(p -> p.price<20).collect(Collectors.toMap(p->p.id, p -> p.name)).forEach((key, value) -> System.out.println(key+ "- "+value));
		
		List<UUID> uuids = Stream.generate(UUID:: randomUUID).limit(4).collect(Collectors.toList());
		List<Integer> rnums = Stream.generate(new Random()::nextInt).limit(4).collect(Collectors.toList());
		
		System.out.println("UUID's :"+uuids);
		System.out.println("Random Numbers are: ");
		rnums.forEach(System.out::println);
		
		//In case if we want random numbers between any limits
		IntStream list= new Random().ints(5,0,10).distinct(); //max 5 random no's are returned, lower limit is 0 and upper limit is 100 
		list.forEach(System.out::println);
		
		
		
	}

}

class ProdData
{
	int id;
	String name;
	int price;
	ProdData(int id,String name,int price)
	{
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
}

