package test.iface.functional;

@FunctionalInterface
public interface CalculateInterface {
	int calculate(int value);
}
